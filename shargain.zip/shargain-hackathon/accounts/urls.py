from typing import Any, List

from django.urls import include, path

app_name = "accounts"

urlpatterns: List[Any] = []
