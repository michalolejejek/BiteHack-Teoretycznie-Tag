// Initialize button with users's prefered color
let sendButton = document.getElementById("send-button");

// chrome.storage.sync.get("color", ({color}) => {
//   changeColor.style.backgroundColor = color;
// });

document.getElementById('channel-dropdown').style.display = 'none';

document.getElementById('target-notifications').addEventListener('change', (event) => {
  document.getElementById('channel-dropdown').style.display = event.currentTarget.checked ? '' : 'none';
})

const setDefaultValues = async () => {
  let [tab] = await chrome.tabs.query({active: true, currentWindow: true});
  document.getElementById("target-name").value = tab.title;
  document.getElementById("target-url").value = tab.url;

  const channels = (await axios.get("https://shargain-hackathon.beyondthe.dev/api/notification-configs/")).data;
  console.log(channels);

  const channelsDropdown = document.getElementById("target-channel");
  channels.forEach(({
                      id,
                      name,
                      channel
                    }) => channelsDropdown.innerHTML += `<option value="${id}">${name} (${channel})</option>`)


}

setDefaultValues();

// When the button is clicked, inject setPageBackgroundColor into current page
sendButton.addEventListener("click", async () => {
  const targetName = document.getElementById("target-name").value;
  const targetUrl = document.getElementById("target-url").value;
  const enableNotifications = document.getElementById('target-notifications').checked;
  const channel = document.getElementById("target-channel").value;

  await
    axios.post("https://shargain-hackathon.beyondthe.dev/api/scrapping-targets/", {
      name: targetName,
      url: targetUrl,
      enable_notifications: enableNotifications,
      notification_config: channel
    });

  // const data = {
  //   name: targetName,
  //   url: targetUrl,
  //   enable_notifications: enableNotifications,
  //   notification_config: channel
  // }

  // await fetch("https://shargain-hackathon.beyondthe.dev/api/scrapping-targets/", {
  //   method: 'POST',
  //   // mode: 'cors', // no-cors, *cors, same-origin
  //   // cache: 'no-cache', // *default, no-cache, reload, force-cache, only-if-cached
  //   // credentials: 'same-origin', // include, *same-origin, omit
  //   // headers: {
  //   //   'Content-Type': 'application/json'
  //   //   // 'Content-Type': 'application/x-www-form-urlencoded',
  //   // },
  //   referrer: 'client',
  //   // redirect: 'follow', // manual, *follow, error
  //   // referrerPolicy: 'no-referrer', // no-referrer, *no-referrer-when-downgrade, origin, origin-when-cross-origin, same-origin, strict-origin, strict-origin-when-cross-origin, unsafe-url
  //   body: JSON.stringify(data) // body data type must match "Content-Type" header
  // });

  // chrome.scripting.executeScript({
  //   target: {tabId: tab.id},
  //   function: setPageBackgroundColor,
  // });
});

// The body of this function will be execuetd as a content script inside the
// current page
function setPageBackgroundColor() {
  chrome.storage.sync.get("color", ({color}) => {
    document.body.style.backgroundColor = color;
  });
}
